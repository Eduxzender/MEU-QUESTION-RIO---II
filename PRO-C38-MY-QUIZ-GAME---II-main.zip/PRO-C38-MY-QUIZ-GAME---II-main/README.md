# PRO-C38-MY-QUIZ-GAME---II
This is the updated Quiz Game from PRO-C37: MY QUIZ GAME - I. This is also connected with Firebase Live Server.
